import mongoose, { Schema, Document } from 'mongoose';

/**
 * Event Model
 * Tracks analytics events (views, conversions, etc.)
 */
export type EventType = 'view' | 'conversion' | 'visit';

export interface IEvent extends Document {
  siteId: string;
  popupId: string;
  userId: string; // Owner ID
  type: EventType;
  createdAt: Date;
}

const EventSchema: Schema = new Schema(
  {
    siteId: {
      type: String,
      required: [true, 'Site ID is required'],
      index: true,
    },
    popupId: {
      type: String,
      required: [true, 'Popup ID is required'],
      index: true,
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: false, // Optional temporarily
      index: true,
    },
    type: {
      type: String,
      enum: ['view', 'conversion', 'visit'],
      required: [true, 'Event type is required'],
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

// Compound index for efficient queries
EventSchema.index({ popupId: 1, type: 1, createdAt: -1 });

export default mongoose.models.Event || mongoose.model<IEvent>('Event', EventSchema);

